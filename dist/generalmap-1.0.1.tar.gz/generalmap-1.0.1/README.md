# GeneralMap
An generalized version of map function in python, can lift basic function over various data structures.
